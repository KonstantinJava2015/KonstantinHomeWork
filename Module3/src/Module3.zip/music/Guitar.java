package music;

/**
 * Created by User on 21.12.2015.
 */
public class Guitar extends musicalInstrument {
}
