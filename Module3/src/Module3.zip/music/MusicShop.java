package music;

import java.util.ArrayList;

/**
 * Created by User on 21.12.2015.
 */
public class MusicShop {
    private ArrayList<musicalInstrument> assortment;

}
