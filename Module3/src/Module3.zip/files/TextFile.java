package files;

/**
 * Created by User on 21.12.2015.
 */
public class TextFile extends File {
}
