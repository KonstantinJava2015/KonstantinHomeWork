package files;

import java.util.ArrayList;

/**
 * Created by User on 21.12.2015.
 */
public class Folder {
    private ArrayList<File> files;
}
