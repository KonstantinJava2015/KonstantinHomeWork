package files;

/**
 * Created by User on 21.12.2015.
 */
public abstract class File {
}
