package flowers;

import java.util.ArrayList;

/**
 * Created by User on 21.12.2015.
 */
public class Rosebush {
    private ArrayList<Rose> roses;
}
